import React from 'react';
import { render, screen } from '@/test/utils/renderWithIntl';
import { vi } from 'vitest';
import en from '@/locales/en.json';

const mockHistory = [
  {
    id: 'tel-aviv_1',
    cityName: 'Tel Aviv',
    temperature: 25,
    timestamp: Date.now() - 60000,
    unit: 'metric' as const,
    tempInCelsius: 25,
  },
  {
    id: 'tel-aviv_2',
    cityName: 'Tel Aviv',
    temperature: 77,
    timestamp: Date.now() - 120000,
    unit: 'imperial' as const,
    tempInCelsius: 25,
  },
];

describe('WeatherHistory', () => {
  beforeEach(() => {
    vi.resetModules();
  });

  it('displays weather history correctly', async () => {
    vi.doMock('@/stores/useWeatherStore', () => ({
      useWeatherStore: (selector: any) => selector({
        WeatherStore: mockHistory,
      }),
    }));
    const WeatherHistory = (await import('./WeatherHistory')).default;
    render(<WeatherHistory />);
    expect(screen.getByText(en.history.title)).toBeInTheDocument();
    expect(screen.getAllByText('Tel Aviv')).toHaveLength(2);
    expect(screen.getByText('25°C')).toBeInTheDocument();
    expect(screen.getByText('77°F')).toBeInTheDocument();
  });

  it('shows empty state when no history', async () => {
    vi.doMock('@/stores/useWeatherStore', () => ({
      useWeatherStore: (selector: any) => selector({
        WeatherStore: [],
      }),
    }));
    const WeatherHistory = (await import('./WeatherHistory')).default;
    render(<WeatherHistory />);
    expect(screen.getByText(en.history.empty)).toBeInTheDocument();
  });

  it('does not show temperature difference for same temperatures in different units', async () => {
    vi.doMock('@/stores/useWeatherStore', () => ({
      useWeatherStore: (selector: any) => selector({
        WeatherStore: mockHistory,
      }),
    }));
    const WeatherHistory = (await import('./WeatherHistory')).default;
    render(<WeatherHistory />);
    expect(screen.queryByRole('presentation')).not.toBeInTheDocument();
  });
});
