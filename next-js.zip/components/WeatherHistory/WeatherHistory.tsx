'use client';

import { useWeatherStore } from '@/stores/useWeatherStore';
import { useTranslations } from 'next-intl';
import { Clock, TrendingUp, TrendingDown } from 'lucide-react';
import { formatTemperature } from '@/lib/helpers';
import { WeatherHistoryItem } from '@/types/history';

export default function WeatherHistory() {
  const t = useTranslations();
  const history = useWeatherStore((s) => s.WeatherStore);

  if (history?.length === 0) {
    return (
      <div className="bg-card rounded-xl p-6 shadow-md border border-border">
        <div className="flex items-center gap-2 mb-4">
          <Clock className="h-5 w-5 text-muted-foreground" />
          <h3 className="text-lg font-semibold text-card-foreground">
            {t('history.title')}
          </h3>
        </div>
        <p className="text-muted-foreground text-center py-8">
          {t('history.empty')}
        </p>
      </div>
    );
  }

  return (
    <div className="bg-card rounded-xl p-6 shadow-md border border-border">
      <div className="flex items-center gap-2 mb-4">
        <Clock className="h-5 w-5 text-muted-foreground" />
        <h3 className="text-lg font-semibold text-card-foreground">
          {t('history.title')}
        </h3>
      </div>
      
      <div className="space-y-3 max-h-64 overflow-y-auto scrollbar-none">
        {history?.map((item, index) => (
          <HistoryItem 
            key={item.id} 
            item={item} 
            previousItem={history[index + 1]}
          />
        ))}
      </div>
    </div>
  );
}

function HistoryItem({ 
  item, 
  previousItem 
}: { 
  item: WeatherHistoryItem;
  previousItem?: WeatherHistoryItem;
}) {
  const t = useTranslations();
  
  // ⭐ השווה בצלזיוס תמיד
  const tempDifference = previousItem && previousItem.cityName === item.cityName
    ? item.tempInCelsius - previousItem.tempInCelsius 
    : 0;
  
  const timeAgo = getTimeAgo(item.timestamp);
  const shouldShowDifference = Math.abs(tempDifference) >= 0.5;
  
  return (
    <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg hover:bg-muted/70 transition-colors">
      <div className="flex items-center gap-3">
        <div className="text-sm">
          <p className="font-medium text-card-foreground">{item.cityName}</p>
          <p className="text-xs text-muted-foreground">{timeAgo}</p>
        </div>
      </div>
      
      <div className="flex items-center gap-2">
        <span className="font-semibold text-card-foreground">
          {formatTemperature(item.temperature, item.unit)}
        </span>
        
        {shouldShowDifference && (
          <div className={`flex items-center gap-1 text-xs ${
            tempDifference > 0 ? 'text-red-500' : 'text-blue-500'
          }`}>
            {tempDifference > 0 ? (
              <TrendingUp className="h-3 w-3" />
            ) : (
              <TrendingDown className="h-3 w-3" />
            )}
            <span>{Math.abs(tempDifference).toFixed(1)}°</span>
          </div>
        )}
      </div>
    </div>
  );
}

function getTimeAgo(timestamp: number): string {
  const now = Date.now();
  const diffMs = now - timestamp;
  const diffMinutes = Math.floor(diffMs / (1000 * 60));
  const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
  
  if (diffMinutes < 1) return 'עכשיו';
  if (diffMinutes < 60) return `לפני ${diffMinutes} דקות`;
  if (diffHours < 24) return `לפני ${diffHours} שעות`;
  
  return new Date(timestamp).toLocaleDateString('he-IL', {
    day: 'numeric',
    month: 'short',
    hour: '2-digit',
    minute: '2-digit'
  });
}