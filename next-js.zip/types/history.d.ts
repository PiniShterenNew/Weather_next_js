export interface WeatherHistoryItem {
    id: string;
    cityName: string;
    temperature: number;
    timestamp: number;
    unit: 'metric' | 'imperial';
    tempInCelsius: number;
}