export interface CityInfo {
  name: string;
  country: string;
  lat: number;
  lon: number;
}